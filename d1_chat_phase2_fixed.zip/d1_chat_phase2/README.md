# Multi-Client Chat Network — D1

Phase 2 extends the working Phase 1 TCP chat application into a Mininet + SDN environment.

## Current D1 status

- ✅ Low-level TCP client/server
- ✅ Concurrent clients
- ✅ Basic broadcast chat
- ✅ Mininet topology definition
- ✅ Open vSwitch using OpenFlow 1.3
- ✅ SDN controller
- ✅ TCP/5000 chat-traffic classification and logging
- ✅ Socket traffic passes through the SDN data plane
- ⏳ D1 runtime validation depends on a local Mininet/Open vSwitch + OS-Ken installation

## Structure

```text
d1_chat_phase2/
├── client/client.py
├── server/server.py
├── sdn/controller.py
├── sdn/run_controller.py
├── mininet/topology.py
├── docs/phase2_scope.md
├── docs/setup.md
├── tests/phase2_test_plan.md
└── README.md
```

## Phase boundary

Do not add D2 mechanisms yet. D2 will later introduce dynamic policies such as congestion handling, prioritization/QoS, rerouting, failure recovery and performance comparison.
